
#include <string>

namespace mmpc_utils {
    
int get_ip_from_verf_code(const char* local_ip,const char* verf_code, char* server_ip);

}